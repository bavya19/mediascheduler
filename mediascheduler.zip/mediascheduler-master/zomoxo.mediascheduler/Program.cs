﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Web.Helpers;
using zomoxo.mediascheduler.Models;
using zomoxo.mediascheduler.Repository;

namespace zomoxo.mediascheduler
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                //Read input from user
                //1. From Time yyyy-MM-dd HH:mm:ss (2019-10-01 10:00:00)
                //2. To Time   yyyy-MM-dd HH:mm:ss (2019-10-01 10:30:00)

                var mediaRepository = new MediaRepository();

                //Create request object based on the above user input then use Media.json from Media folder
                //to create media object. Construct the below request using both the input

                //Read Input from user

                Console.WriteLine("Enter From Time in yyyy-MM-dd HH:mm:ss Format");
                string FromDate = Console.ReadLine();
                Console.WriteLine("Enter To Time in yyyy-MM-dd HH:mm:ss Format");
                string ToDate = Console.ReadLine();

                var request = new GenerateScheduleRequest();

                request.FromDate = Convert.ToDateTime(FromDate);
                request.ToDate = Convert.ToDateTime(ToDate);
                TimeSpan ts = request.ToDate - request.FromDate;
                string msg = String.Format("Elapsed Time : " + ts.TotalMinutes);
                Console.WriteLine(msg);
                int ttime = Convert.ToInt32(ts.TotalMinutes);

                var jsonData = File.ReadAllText(@"C:\Users\Downloads\mediascheduler-master\mediascheduler-master\zomoxo.mediascheduler\Media\Medias.json");
                mymedia ss = JsonConvert.DeserializeObject<mymedia>(jsonData);
                Console.WriteLine(ss.play[1].MediaName);
                int listen = ss.play.Count;
                Console.WriteLine("count : " + listen);
                Console.WriteLine("**************************** Play Sequence/Schedule *********************");
                string path = @"C:\Users\Desktop\New folder\doc.json";
                if (!File.Exists(path))
                {
                    // Create a file to write to.
                    using (StreamWriter sw = File.CreateText(path))
                    {
                        sw.WriteLine(" ");
                    }
                }
                for (int i = 1; i <= listen; i++)
                {
                    for (int y = 0; y < listen; y++)
                    {
                        if (i == ss.play[y].Priority)
                        {
                            int reducetime = ttime + ss.play[y].Duration;
                            if (reducetime < 0) { reducetime = ttime; continue; }
                            else { ttime = reducetime; };
                            Console.WriteLine(ss.play[y].MediaName + ", Priority: " + ss.play[y].Priority + ", Duration: " + ss.play[y].Duration);
                            using (StreamWriter sw = File.AppendText(path))
                            {
                                sw.WriteLine("{ \n \"MediaName\": " + ss.play[y].MediaName);
                                sw.WriteLine(" \"Duration\": " + ss.play[y].Duration);
                                sw.WriteLine(" \"NumberOfTimesToPlay\": " + ss.play[y].NumberOfTimesToPlay);
                                sw.WriteLine(" \"Priority\": " + ss.play[y].Priority + "\n}");
                            }
                        }
                    }

                }
                Console.WriteLine("**************************** End of Sequence/Schedule *********************");
            }



            catch (Exception e)
            {
                Console.WriteLine($"Something went wrong {e}");
            }

                Console.ReadKey();
            }
    }
}



        
