using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.SqlServer.Server;

namespace zomoxo.mediascheduler.Models
{
    /// <summary>
    /// Schedule Request Payload
    /// </summary>
    

   
    public class GenerateScheduleRequest
        {
            public DateTime FromDate { get; set; }
            public DateTime ToDate { get; set; }
            public IList<Media> Medias { get; set; }
        
            
            public class Scheduler
            {
                private List<Media> Media = new List<Media>();

                private Scheduler() 
            { 
            }

                public void Schedule(int FromDate, int ToDate)
                {
                    DateTime now = DateTime.Now;
                    DateTime request = new DateTime(now.Year, now.Month, now.Day);
                }
            }
        }
    }


