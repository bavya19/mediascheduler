using zomoxo.mediascheduler.Models;

namespace zomoxo.mediascheduler.Repository
{
    public class MediaRepository : IMediaRepository
    {
        /// <inheritdoc />
        public GeneratedScheduleResponse GenerateSchedule(GenerateScheduleRequest request)
        {
            //Implement scheduling
            throw new System.NotImplementedException();
        }
    }
}