# Media Scheduler

Media scheduler excercise, for given from time to to time generate media playlist for the given Media.json file. Based on number of times to play, priority, duration from media.json generate the schedule for the given from time to to time.
